#import "ACRemote.h"

@implementation ACRemote
+(NSDictionary *)columnPropertyPair{
    NSMutableDictionary *dict = [NSMutableDictionary dictionary];
    
    [dict setValue:@"idValue" forKey:@"idValue"];
    [dict setValue:@"title" forKey:@"title"];
    return dict;
}
@end
