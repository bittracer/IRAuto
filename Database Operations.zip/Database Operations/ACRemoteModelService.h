
#import <Foundation/Foundation.h>
#import "ACRemote.h"
#import "IRDatabase.h"


@interface ACRemoteModelService : NSObject
+(NSArray *)getACRemoteForQuery:(NSString *)query;
+(NSArray *)getACRemotes;

@end
