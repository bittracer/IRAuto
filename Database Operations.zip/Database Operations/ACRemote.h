
#import <Foundation/Foundation.h>

@interface ACRemote : NSObject

@property(nonatomic) NSString *title;
@property(nonatomic) int *idValue;

@end
