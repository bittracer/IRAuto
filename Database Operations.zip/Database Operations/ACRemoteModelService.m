#import "ACRemoteModelService.h"

@implementation ACRemoteModelService

+(NSArray *)getACRemoteForQuery:(NSString *)query
{
    return [IRDatabase executeSelectQuery:query objectType:[ACRemote class]];
}
+(NSArray *)getACRemotes
{
    NSString *query = [NSString stringWithFormat:@"select * from tb_announcements WHERE website_id=%d AND is_active=1 ORDER BY announcement_date DESC,announcement_time DESC",websiteId];
    NSArray *alerts = [self getAlertsForQuery:query];
    return alerts;
}

@end
